hmLoadTopic({
hmKeywords:"",
hmTitle:"Команда Болты ГОСТ 7787-81",
hmDescription:"Команда служит для вставки в документ изображений или моделей болтов по 7787-81.",
hmPrevLink:"",
hmNextLink:"",
hmParentLink:"settings_to_work_with_applications.html",
hmBreadCrumbs:"",
hmTitlePath:"Общие сведения о прикладных библиотеках > Настройка КОМПАС-3D для работы с прикладными библиотеками > Управление характерными точками библиотечных элементов",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\" style=\"font-weight: normal;\">Команда<\/span><span class=\"f_Heading1\"> Болты ГОСТ 7787-81<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_bodytext\"><span class=\"f_bodytext\">Команда служит для вставки в документ изображений или моделей болтов по 7787-81.<\/span><\/p>\n\r"
})
