﻿var hmContextIds = new Array();
function hmGetContextId(query) {
    var urlParams;
    var match,
        pl = /\+/g,
        search = /([^&=]+)=?([^&]*)/g,
        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
    params = {};
    while (match = search.exec(query))
       params[decode(match[1])] = decode(match[2]);
    if (params["contextid"]) return decodeURIComponent(hmContextIds[params["contextid"]]);
    else return "";
}

hmContextIds["1"]="insert_general.html";
hmContextIds["25000"]="z_library_modes.html";
hmContextIds["3"]="assm_aper_dlg_help.html";
hmContextIds["2"]="assm_dlg_help.html";
hmContextIds["217"]="config_dlg_help.html";
