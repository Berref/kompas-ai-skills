hmLoadTopic({
hmKeywords:"",
hmTitle:"Крепежный элемент",
hmDescription:"Элемент, состоящий из нескольких крепежных изделий, например, болт — шайба — гайка и т.п.",
hmPrevLink:"",
hmNextLink:"",
hmParentLink:"settings_to_work_with_applications.html",
hmBreadCrumbs:"",
hmTitlePath:"Общие сведения о прикладных библиотеках > Настройка КОМПАС-3D для работы с прикладными библиотеками > Управление характерными точками библиотечных элементов",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Крепежный элемент<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_bodytext\"><span class=\"f_bodytext\">Элемент, состоящий из нескольких крепежных изделий, например, болт — шайба — гайка и т.п.<\/span><\/p>\n\r"
})
