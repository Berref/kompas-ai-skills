hmLoadTopic({
hmKeywords:"",
hmTitle:"Работа с прикладной библиотекой в режиме меню",
hmDescription:"В этом режиме структура библиотеки отображается в виде стандартного иерархического меню.",
hmPrevLink:"z_library_modes.html",
hmNextLink:"z_dialog.html",
hmParentLink:"library_modes.html",
hmBreadCrumbs:"<a href=\"applications_general.html\">Общие сведения о прикладных библиотеках<\/a> &gt; <a href=\"library_modes.html\">Режимы работы с библиотекой<\/a>",
hmTitlePath:"Общие сведения о прикладных библиотеках > Режимы работы с библиотекой > Работа с прикладной библиотекой в режиме меню",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Работа с прикладной библиотекой в режиме меню<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_bodytext\"><a id=\"xac425171\" class=\"hmanchor\"><\/a><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">В этом режиме структура библиотеки отображается в виде стандартного иерархического меню.<\/span><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">Название библиотеки отображается в виде команды в меню <\/span><span class=\"f_bodytext\" style=\"font-weight: bold;\">Библиотеки<\/span><span class=\"f_bodytext\">. При вызове этой команды раскрывается вложенное меню, содержащее функции библиотеки в виде команд (они могут быть сгруппированы по разделам).<\/span><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">Для запуска функции на исполнение выберите из меню <\/span><span class=\"f_bodytext\" style=\"font-weight: bold;\">Библиотеки<\/span><span class=\"f_bodytext\"> команду меню с названием нужной функции.<\/span><\/p>\n\r"
})
