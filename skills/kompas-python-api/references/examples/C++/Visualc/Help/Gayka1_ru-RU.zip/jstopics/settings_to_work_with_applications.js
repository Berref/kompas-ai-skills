hmLoadTopic({
hmKeywords:"",
hmTitle:"Настройка КОМПАС-3D для работы с прикладными библиотеками",
hmDescription:"Отключение библиотек Управление характерными точками библиотечных элементов",
hmPrevLink:"z_detach_library.html",
hmNextLink:"z_lib_sw_off_setting.html",
hmParentLink:"applications_general.html",
hmBreadCrumbs:"<a href=\"applications_general.html\">Общие сведения о прикладных библиотеках<\/a>",
hmTitlePath:"Общие сведения о прикладных библиотеках > Настройка КОМПАС-3D для работы с прикладными библиотеками",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Настройка КОМПАС-3D для работы с прикладными библиотеками<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_lib_sw_off_setting.html\" class=\"topiclink hmlinklistitem\">Отключение библиотек<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_hot_point_using_setting.html\" class=\"topiclink hmlinklistitem\">Управление характерными точками библиотечных элементов<\/a><\/span><\/p>\n\r"
})
