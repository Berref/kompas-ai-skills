hmLoadTopic({
hmKeywords:"",
hmTitle:"Режимы работы с библиотекой",
hmDescription:"Общие сведения о режимах работы с библиотекой Работа с прикладной библиотекой в режиме меню Работа с прикладной библиотекой в режиме диалога Работа с прикладной библиотекой в ре",
hmPrevLink:"z_attach_library.html",
hmNextLink:"z_library_modes.html",
hmParentLink:"applications_general.html",
hmBreadCrumbs:"<a href=\"applications_general.html\">Общие сведения о прикладных библиотеках<\/a>",
hmTitlePath:"Общие сведения о прикладных библиотеках > Режимы работы с библиотекой",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Режимы работы с библиотекой<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_library_modes.html\" class=\"topiclink hmlinklistitem\">Общие сведения о режимах работы с библиотекой<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_menu.html\" class=\"topiclink hmlinklistitem\">Работа с прикладной библиотекой в режиме меню<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_dialog.html\" class=\"topiclink hmlinklistitem\">Работа с прикладной библиотекой в режиме диалога<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_window.html\" class=\"topiclink hmlinklistitem\">Работа с прикладной библиотекой в режиме окна<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_panel.html\" class=\"topiclink hmlinklistitem\">Работа с прикладной библиотекой в режиме панели<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"z_library_mode_change.html\" class=\"topiclink hmlinklistitem\">Изменение режима работы с библиотекой<\/a><\/span><\/p>\n\r"
})
