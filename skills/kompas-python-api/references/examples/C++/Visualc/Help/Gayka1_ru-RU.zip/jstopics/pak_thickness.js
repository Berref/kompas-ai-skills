hmLoadTopic({
hmKeywords:"",
hmTitle:"Толщина пакета",
hmDescription:"Суммарная толщина скрепляемых деталей со сквозным отверстием (без учета глубины ввинчивания), показано на рисунке.",
hmPrevLink:"",
hmNextLink:"",
hmParentLink:"settings_to_work_with_applications.html",
hmBreadCrumbs:"",
hmTitlePath:"Общие сведения о прикладных библиотеках > Настройка КОМПАС-3D для работы с прикладными библиотеками > Управление характерными точками библиотечных элементов",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Толщина пакета<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_bodytext\"><span class=\"f_bodytext\">Суммарная толщина скрепляемых деталей со сквозным отверстием (без учета глубины ввинчивания), показано на рисунке.<\/span><\/p>\n\r<div style=\"text-align: left; text-indent: 0; line-height: 1.48; padding: 0 0 0 0; margin: 0.2500rem 0 0 4.1250rem;\"><table style=\"width:100%; border:none; border-spacing:0;\">\n\r<tr>\n\r<td style=\"vertical-align:top; padding:0.1875rem; border:none\"><p class=\"p_Image_Center\"><img alt=\"pak_thic\" style=\"margin:0.0625rem auto 0.0625rem auto;width:25.6250rem;height:15.7500rem;border:none\" src=\".\/images\/pak_thic.png\"\/><\/p>\n\r<\/td>\n\r<\/tr>\n\r<\/table>\n\r<\/div>\n\r"
})
