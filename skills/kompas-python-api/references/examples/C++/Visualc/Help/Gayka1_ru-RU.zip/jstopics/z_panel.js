hmLoadTopic({
hmKeywords:"",
hmTitle:"Работа с прикладной библиотекой в режиме панели",
hmDescription:"Панель библиотеки располагается на вкладке Менеджера библиотек.",
hmPrevLink:"z_window.html",
hmNextLink:"z_library_mode_change.html",
hmParentLink:"library_modes.html",
hmBreadCrumbs:"<a href=\"applications_general.html\">Общие сведения о прикладных библиотеках<\/a> &gt; <a href=\"library_modes.html\">Режимы работы с библиотекой<\/a>",
hmTitlePath:"Общие сведения о прикладных библиотеках > Режимы работы с библиотекой > Работа с прикладной библиотекой в режиме панели",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Работа с прикладной библиотекой в режиме панели<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_bodytext\"><a id=\"xac425194\" class=\"hmanchor\"><\/a><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">Панель библиотеки располагается на вкладке <\/span><span class=\"f_bodytext\" style=\"font-weight: bold;\">Менеджера библиотек<\/span><span class=\"f_bodytext\">.<\/span><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">Команды работы с библиотекой находятся в контекстном меню вкладки.<\/span><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">На панели библиотеки может располагаться несколько окон. В одном из них показана структура (список разделов) библиотеки. В другом —список названий команд и набор слайдов (значков), которые соответствуют пунктам выделенного в списке раздела библиотеки. Третье окно служит для просмотра слайда, выделенного в списке команд. вы можете изменять размер панели или любого окна на ней.<\/span><\/p>\n\r<p class=\"p_bodytext\"><span class=\"f_bodytext\">Для запуска библиотечной команды на исполнение выберите ее название в списке и нажмите клавишу <\/span><span class=\"f_bodytext\" style=\"font-style: italic;\">&lt;Enter&gt;<\/span><span class=\"f_bodytext\"> или дважды щелкнуть левой кнопкой мыши на названии команды.<\/span><\/p>\n\r"
})
