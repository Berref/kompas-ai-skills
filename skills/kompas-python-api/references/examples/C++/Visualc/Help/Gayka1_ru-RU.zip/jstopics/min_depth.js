hmLoadTopic({
hmKeywords:"",
hmTitle:"Глубина ввинчивания",
hmDescription:"Глубина, на которую винт или болт будет ввинчен в резьбовое отверстие (показано на рисунке). На чертеже эта величина может оказаться чуть больше из-за того, что длина болтов и...",
hmPrevLink:"",
hmNextLink:"",
hmParentLink:"settings_to_work_with_applications.html",
hmBreadCrumbs:"",
hmTitlePath:"Общие сведения о прикладных библиотеках > Настройка КОМПАС-3D для работы с прикладными библиотеками > Управление характерными точками библиотечных элементов",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Глубина ввинчивания<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_bodytext\"><span class=\"f_bodytext\">Глубина, на которую винт или болт будет ввинчен в резьбовое отверстие (показано на рисунке). На чертеже эта величина может оказаться чуть больше из-за того, что длина болтов и винтов стандартизована.<\/span><\/p>\n\r<div style=\"text-align: left; text-indent: 0; line-height: 1.48; padding: 0 0 0 0; margin: 0.2500rem 0 0 4.1250rem;\"><table style=\"width:100%; border:none; border-spacing:0;\">\n\r<tr>\n\r<td style=\"vertical-align:top; padding:0.1875rem; border:none\"><p class=\"p_Image_Center\"><img alt=\"mindepth\" style=\"margin:0.0625rem auto 0.0625rem auto;width:21.5000rem;height:12.6875rem;border:none\" src=\".\/images\/mindepth.png\"\/><\/p>\n\r<\/td>\n\r<\/tr>\n\r<\/table>\n\r<\/div>\n\r"
})
