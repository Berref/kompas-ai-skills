hmLoadTopic({
hmKeywords:"",
hmTitle:"Вставка библиотечных элементов",
hmDescription:"Общий порядок вставки элемента из библиотеки Вставка библиотечного элемента в графический документ (чертеж, фрагмент) Вставка библиотечного элемента в документ-сборку Вставка би",
hmPrevLink:"index.html",
hmNextLink:"insert_general.html",
hmParentLink:"index.html",
hmBreadCrumbs:"",
hmTitlePath:"Вставка библиотечных элементов",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Вставка библиотечных элементов<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"insert_general.html\" class=\"topiclink hmlinklistitem\">Общий порядок вставки элемента из библиотеки<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"inset_element.html\" class=\"topiclink hmlinklistitem\">Вставка библиотечного элемента в графический документ (чертеж, фрагмент)<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"inset_element_3d.html\" class=\"topiclink hmlinklistitem\">Вставка библиотечного элемента в документ-сборку<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"inset_element_sp.html\" class=\"topiclink hmlinklistitem\">Вставка библиотечного элемента в документ-спецификацию<\/a><\/span><\/p>\n\r"
})
