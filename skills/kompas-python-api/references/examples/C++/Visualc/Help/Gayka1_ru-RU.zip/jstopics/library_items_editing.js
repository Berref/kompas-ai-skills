hmLoadTopic({
hmKeywords:"",
hmTitle:"Редактирование библиотечных элементов",
hmDescription:"Редактирование библиотечного элемента в графическом документе",
hmPrevLink:"inset_element_sp.html",
hmNextLink:"edit_element.html",
hmParentLink:"index.html",
hmBreadCrumbs:"",
hmTitlePath:"Редактирование библиотечных элементов",
hmHeader:"<h1 class=\"p_Heading1\"><span class=\"f_Heading1\">Редактирование библиотечных элементов<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"edit_element.html\" class=\"topiclink hmlinklistitem\">Редактирование библиотечного элемента в графическом документе<\/a><\/span><\/p>\n\r<p class=\"p_Z_LOC_TOC\"><span class=\"f_Z_LOC_TOC\"><a href=\"edit_element_3d.html\" class=\"topiclink hmlinklistitem\">Редактирование библиотечного элемента в документе-сборке<\/a><\/span><\/p>\n\r"
})
